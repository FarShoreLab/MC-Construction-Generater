# 地形调节包 v0.4.2：实际验证

## 判定

本次为原地形生成器的参数化重制。新增参数进入真实体素／高度场，并完整贯通浏览器、HTTP、Java生成、原规划与施工链。没有重新设计建筑分布或道路拓扑。

### 默认兼容

在修改前的原版源码上捕获32组完整世界SHA-256，包括四种地形、32×48／128×128／192×96／512×512、不同基准与起伏、种子42与-731。修改后的原签名和显式默认参数重载都逐一匹配原哈希。哈希包含边界与每个体素ID，覆盖水体、地质层和树木，不只是高度图。

证据：`evidence/baseline-world-hashes.csv`、`evidence/default-world-hashes.csv`、`evidence/tests/terrain-controls/results.json`。新增测试读取固化旧版期望值，不在运行时重生成“基线”。

另外重跑上一版五个场景，均保持原地形哈希和planHash一致：reference512、reproduction512、mixed128、loop128、custom192x96。说明这次没有通过更改默认建筑位置／道路来制造地形改善的假象；原规划的剩余质量限制也没有被此版本消除。见 `evidence/legacy-plan-replay.json`。

## 新增测试

**69项可执行Java测试通过。** 包含32组旧版哈希、两种丘陵入口、10项元数据／Java默认与范围一致性、10项真实世界低值／高值差异、非有限值／未知键／空值拒绝、四类地形的单点采样与扫描地表一致性、确定性、树木参数与地表／水位分离、水位单调关系、山脊收窄和谷地展开方向、台地分级、类型无关参数不生效，以及自定义参数下的真实3栋建筑施工与独立TerrainAudit零违规。

**独立无Gson运行通过。** 仅编译生成器、参数record、体素世界、SpatialNoise四个类和示例即可完成地形生成与采样；输出见 `evidence/standalone/run.log`。

## HTTP与界面

新增地形API套件共79个请求：13个正常200、66个预期参数拒绝400。四类默认、非方形自定义参数重复、512地图、自定义参数下的terrain／plan／roll原地形一致性、元数据、非法与重复参数均通过。地形-only没有plan、constructed或规划搜索统计。见 `evidence/terrain-api/results.json`。

旧API套件通过：12个正常／预算场景，加原参数拒绝、重复、环路、建筑预设与并发429检查。见 `evidence/existing-api/api-checks.json`。原预算拒绝仍保留，不提高搜索或施工配额。

512×512、treeDensity=2、treeSpacing=2、waterLevelRatio=0的极端组合实测返回400及 `EXTRA_VOXEL_LIMIT_NO_TRUNCATION`。没有为截图截断可见体素，也没有偷改输入；见 `evidence/terrain-limit.json`。

浏览器实际执行原应用JS及真实Java API，交互检查通过，pageErrors为空：10项调低／调高说明、类型专属项隐藏、切换类型的水位默认与自定义保留、数值／滑杆同步、只生成地形、只重新规划保留已生成参数、原方案比较、非法输入后恢复。截图与实际config／metrics在 `evidence/browser/`。

**浏览器验证边界：** 托管Chromium直连loopback被管理员策略阻止；使用原测试方式的Python→真实本机HTTP桥接，不是API模拟。WebGL不可用，截图和交互验证为2D兼容模式。没有声称原生WebGL渲染或Minecraft游戏运行通过。

## 原测试套件

| 套件 | 结果 |
|---|---|
| core-21 | PASS，退出码0 |
| adaptive-29 | PASS，退出码0 |
| fuzz-100 | PASS，退出码0 |
| organic-presets-25 | PASS，退出码0 |
| route-richness | PASS，退出码0 |
| terrain-controls | PASS，退出码0 |
| bridge-diagonal | PASS，退出码0 |
| fabric-syntax-only | PASS，退出码0 |
| bridge-loopback | PASS，退出码0 |

完整输出保存在 `evidence/tests/`。core-21、adaptive-29、100例fuzz、organic-presets-25、route-richness及两类桥接保持通过。fabric-syntax-only仅表示语法解析，不是Fabric依赖类型构建或游戏实测。

## 调低／调高的实际观测

以下来自192×192、基准58、起伏24、种子42、其余参数为所选类型默认值。每项在适用类型上单独改变。平均相邻格高差只是描述地表，不是规划质量分数；这些例子不能推出所有种子都严格单调。

| 参数 | 低值→高值 | 平均相邻格高差 | 树木株数 |
|---|---|---|---|
| horizontalScale（rolling_hills） | 0.25→4 | 0.3185→0.0140 | 281→326 |
| detailStrength（rolling_hills） | 0→2 | 0.0637→0.0977 | 191→181 |
| waterLevelRatio（rolling_hills） | 0→1 | 0.0744→0.0744 | 326→0 |
| warpStrength（rolling_hills） | 0→2 | 0.0734→0.0776 | 184→178 |
| slopeStrength（rolling_hills） | 0→2 | 0.0730→0.0747 | 179→197 |
| ridgeSharpness（mountain） | 0.5→3 | 0.0712→0.1746 | 326→90 |
| valleyWidth（valley） | 0.5→2 | 0.0718→0.0693 | 300→101 |
| terraceLevels（plateau） | 2→12 | 0.1288→0.0949 | 206→170 |
| treeDensity（rolling_hills） | 0→2 | 0.0744→0.0744 | 0→263 |
| treeSpacing（rolling_hills） | 2→10 | 0.0744→0.0744 | 447→30 |

各项完整世界哈希在 `evidence/tests/terrain-controls/results.json`。树木或水位调节保持高度图不变，并不要求地表材质或树冠也不变。

## 实际环境与未执行项

Java 21.0.11；真实Gson 2.8.9（本地已有jar提供）。项目声明的Gson2.10.1没有在此环境执行验证，依赖声明未修改；没有伪造Gson替身。Python版本、jar哈希等见 `evidence/tests/environment.json`。

未执行：完整Fabric依赖类型构建、Minecraft游戏运行、原生WebGL。未新增或验证多片区聚落规划。原PlanningIR／项目构建版本号保持0.4.0，地形生成器版本标记为terrain-block/0.4.2，本包发行版本为0.4.2。

所有计时是本机测试记录，不是隔离硬件与负载后的性能基准。

## 复跑

在source目录运行使用说明中的构建、新地形API、旧API和浏览器脚本。测试要求本地真实依赖；浏览器套件另需本地Playwright及Chromium，不自动联网下载。

## 交付补丁复核

分发补丁已对干净v0.4.1源码通过 `git apply --check` 并实际应用。应用后全部 **125个源码树文件** 与本包source逐字节一致；见 `evidence/patch-replay.json`。这里的文件数包括源码、资源、脚本与文档，不是仅Java文件数。
