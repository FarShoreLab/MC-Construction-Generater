import java.util.Map;
import org.mcsettlement.planner.simulation.*;
public class TerrainApiExample {
    public static void main(String[] args) {
        String type="rolling_hills";
        TerrainParameters parameters=TerrainParameters.fromOverrides(type,Map.of(
                "horizontalScale","1.5","detailStrength","0.5","waterLevelRatio","0.15","treeDensity","0.5"));
        SimulatedVoxelWorld world=TerrainBlockGenerator.generateWorld(128,128,58,24,type,42L,parameters);
        int y=TerrainBlockGenerator.sampleSurfaceY(64,64,128,128,58,24,type,42L,parameters);
        if(!world.getBlock(64,y,64).isSolid)throw new AssertionError("Sampler mismatch");
        System.out.println("PASS standalone JDK-only terrain generation, surfaceY="+y+", waterY="+TerrainBlockGenerator.waterLevel(58,24,parameters));
    }
}
