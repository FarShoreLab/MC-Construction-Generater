import org.mcsettlement.planner.simulation.*;
public class TerrainBaseline {
 public static void main(String[] args){
  for(String type:new String[]{"rolling_hills","mountain","valley","plateau"})
   for(int[] p:new int[][]{{32,48,50,4},{128,128,58,24},{192,96,63,12},{512,512,75,36}})
    for(long seed:new long[]{42L,-731L}){
     var w=TerrainBlockGenerator.generateWorld(p[0],p[1],p[2],p[3],type,seed);
     System.out.printf("%s,%d,%d,%d,%d,%d,%s%n",type,p[0],p[1],p[2],p[3],seed,SimulatedSettlementPipeline.hashWorld(w));
    }
 }
}
