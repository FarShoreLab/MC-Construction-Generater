# 基线执行环境说明

本包baseline是这次在原始上传源码上实际重跑的结果。旧构建脚本environment.json中的declared_gson只记录项目声明，不检查真实版本。

本次所有基线与新版本均实际使用本机已有的真实Gson **2.8.9**（新脚本增加了jar内pom.properties校验）。原始baseline日志和环境JSON没有改写；本补充说明纠正“声明2.10.1就代表已运行2.10.1”的误读。准确2.10.1未验证，未附系统jar。
