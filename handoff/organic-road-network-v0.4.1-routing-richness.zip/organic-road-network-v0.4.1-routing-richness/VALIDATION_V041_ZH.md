# 路线丰富度 v0.4.1：实际验证报告

## 1. 结论与判定边界

本次修改实际道路中心线、路由选择与提交前验证，不改地形生成、建筑预设或前端布局。五个指定场景均为 COMPLETE、7/7 建筑、CONNECTED_WITH_LOOPS，独立 TerrainAudit 的违规数为 0。建筑预设、占地、平台、门口及私有入口路径在新旧结果中完全相同，仅入口关联到的道路图边 ID 随重建而变化；原始地形哈希一致。

同一最终源码对五个场景各执行两次。planHash、originalTerrainHash、constructedWorldHash 及完整 transportNetwork / groundColumns / plots 结构均一致；不比较 elapsedNanos 等计时字段。浏览器五个场景的 planHash 也与独立导出一致。

本次不是“所有路线均已小于16步”的交付：reference512 与 mixed128 保留明确质量警报。16步仍是软告警，不以取消建筑、穿水、侵占建筑或放宽坡度来满足它。

| 场景 | 建筑（前→后） | verified loop（前→后） | 主干最大连续同向步数 | 全路线长直段长度占比 | 判定 |
|---|---:|---:|---:|---:|---|
| reference512 | 7→7 | 1→1 | 38→32 | 49.45%→9.58% | 保留质量警报 |
| reproduction512 | 7→7 | 1→1 | 24→13 | 9.23%→0.00% | 通过 |
| mixed128 | 7→7 | 0→1 | 24→24 | 20.88%→12.77% | 保留质量警报 |
| loop128 | 7→7 | 1→1 | 14→8 | 0.00%→0.00% | 通过 |
| custom192x96 | 7→7 | 1→1 | 8→13 | 0.00%→0.00% | 通过 |

“主干”在此表专指 collector。长直段占比的分子是每条 corridor 内连续相同离散方向超过16步的整段中心线长度，分母是所有 corridor 中心线长度之和；重叠路线各自计数，不是独立铺装面积占比。mixed128 新增一条环路也改变了分母，不能据占比下降声称其24步直段已被修复。custom192x96 的最长同向段由8步变为13步，仍在阈值内；不把更短的 run 当作越短越好，以避免用细碎摆动刷分。

### 参考512的三条主干

| 路线 | 最大同向步数（前→后） | 有效弯折（前→后） | 绕行率（前→后） |
|---|---:|---:|---:|
| organic_1 | 18→7 | 2→5 | 1.171→1.292 |
| organic_2 | 38→15 | 3→12 | 1.107→1.207 |
| organic_3 | 36→32 | 4→12 | 1.500→1.519 |

复现512的 organic_2 由24步降至13步，绕行率由1.107变为1.138。最终复现场景全部路线最大值为14步，包含 secondary；collector 最大值为13步。

## 2. 输入与公平比较

所有场景基准高度58、地形种子42、目标建筑7；其余参数如下：

| 场景 | 宽×深 | terrainType | relief | planSeed | directions | diagonalBuildings | presetPalette |
|---|---|---|---:|---:|---:|---|---|
| reference512 | 512×512 | mountain | 24 | 42 | 8 | false | classic |
| reproduction512 | 512×512 | rolling_hills | 24 | 45 | 12 | false | mixed |
| mixed128 | 128×128 | rolling_hills | 12 | 42 | 8 | false | mixed |
| loop128 | 128×128 | rolling_hills | 4 | 42 | 8 | false | classic |
| custom192x96 | 192×96 | rolling_hills | 24 | 43 | 12 | true | classic |

独立导出的 singlePresetId 均为 square_cabin。classic/mixed 不是 single 模式，该字段不决定模板选择。

**交接表的一处参数错误：** `terrainType=classic` 不是有效地形类型。classic 是预设组。reference512 使用交接包原始 reference512 JSON 和现有验证脚本中的 mountain / classic 配置，并非为改善结果偷偷换地形。API 测试额外确认 terrainType=classic 返回400。

基线是在修改前复制的源码 `/mnt/data/route_baseline` 编译执行；新旧两端使用同一份 RouteRichnessExport.java、同一Java/Gson环境与原默认预算。before/reproduction512 的 planHash 为 `0b2519f2211e97bb446bdbd9f8c6958b3569c4acf57849cca7f72e1697da75ee`，与输入复现数据一致。comparison.json 记录逐场景公平性断言。

## 3. 剩余长直段、节奏警报与原因

### reference512 / organic_3

保留32步和23步直段；最长32步段位于 (202,310)→(170,310)，高度64。四种丰富 guide 与保守 guide 在各自有界尝试中均耗尽路线配额，因而选中显式 `constrained_fallback`。随后真实中心线补形改掉了若干其他长段，但共享的2048补形工作额用尽。

日志记录了 (191,309)、(193,309) 附近的全宽/障碍/高度检查拒绝、完整铺装/楼梯求解拒绝，以及部分方案土方—质量综合分不优。该路线仍有3个“两步/三步为块”的短周期摆动窗口，与基线同为3；一次局部节奏重排未通过全路铺装求解，故没有提交。

这些是本次有限候选的具体失败与取舍，不是“这里任何曲线在数学上都不可能”的证明。已将它保留为质量警报，而不是宣布直线问题全部消失。

### mixed128

organic_2 仍有24步直段，坐标 (21,95)→(21,119)，高度65。四次稀疏偏移分别在 (18,104)、(22,102) 的全宽/障碍/高度检查处失败，因此保留原可施工路线并标明无 guide 回退。

新增 secondary organic_11 有17步直段，(27,120)→(44,120)。四次补形在 (32,118)、(33,123) 的检查处失败，保留告警。并未移动既有建筑以腾出曲线空间。

所有五个场景逐路线 ABAB 微锯齿窗口均为0。新增的多步摆动统计中，reference512 为3，其余四场景为0。这个额外统计没有把旧的 ABAB 判据替换掉。

## 4. reproduction512 的两个 ring 失败

最终仍有两次“第二条冗余环边”的连接失败，**没有删除、伪装或笼统写成不可行**。既有1个 verified loop 和整体连通性保持。

- plaza_1→plaza_2：四个丰富候选先耗尽各自路线配额；保守候选为 NO_NEW_PAVED_LOOP，未增加有效铺装围合；无 guide 候选为 GOAL_GRADE_OR_STAIRS_REJECTED。
- plaza_2→plaza_3：两个丰富候选用尽配额，第三个触及全局 PATH_EXPANSIONS=180000，停止后续候选。

已接受的 secondary 本身由显式无 guide 回退产生，之后执行4次真实短周期重排，完整铺装与环路审计通过。不能把“secondary 已构成一个环”与“所有追加 ring 尝试均成功”混为一谈。

完整逐次记录见 after/reproduction512/PlanningIR.json 的 transportNetwork.metrics.routingAttempts，及 comparison.json 的 routeFailureReasons。

## 5. 搜索、内存与施工上限

保持原默认上限：candidateChecks=24000、pathExpanded=180000、每次寻路 pathStates=100000、open nodes≤2×pathStates、gradeRelaxations=2000000、groundColumns=40000、constructionEdits=500000、topologyEdgesTried≤128。

每条语义连接最多4个丰富候选、1个保守候选、1个无 guide 候选。连接总配额≤45000，非最后一次尝试≤10000；它们全部受剩余全局180000配额截断。选中候选后的附加真实中心线处理最多再使用2048路径工作额，同样扣原全局余额，绝不在余额耗尽后另开免费搜索。

补形最多16个偏移模板、4次接受，单模板覆盖原路线≤48步。短周期整理最多检查2048个模式窗口、局部重排≤16次；逐段全宽检查和补形高度DP记入 refinementExpanded，它是 pathExpanded 的子集。pattern窗口的轻量比较另由 rhythmWindowsChecked 审计。原有grade求解照常计入原grade预算。

每组 guide 固定5个提案，每个最多7控制点、每段最多1025个采样点、最多128个全宽地形预评分采样。预评分计入 guideProbeCells，不伪装成A*展开。仅对实际尝试的 guide 分配两个 int[width×depth] 场；512地图额外场约2MiB/次，不同时保留全部候选场。两遍网格扫描记为 guideFieldCellVisits，最多128次field build；512地图理论上限为67,108,864次网格单元访问，不等于免费计算。

| 场景 | 路径工作额（前→后） | 新 guide 场次数 | guide 场网格访问 | 新补形/节奏工作额 | 无 guide / 保守 guide 已选路线 |
|---|---:|---:|---:|---:|---:|
| reference512 | 128972→137724 | 20 | 10485760 | 2048 | 1 / 1 |
| reproduction512 | 180000→180000 | 36 | 18874368 | 56 | 1 / 2 |
| mixed128 | 180000→179403 | 35 | 1146880 | 198 | 1 / 1 |
| loop128 | 14685→28155 | 18 | 589824 | 12 | 0 / 0 |
| custom192x96 | 160381→149416 | 30 | 1105920 | 36 | 2 / 0 |

“路径工作额”除原有A*、粗启发式展开，还包含新补形DP/逐段检查。因此这些计数不是纯A*节点扩展的性能对比。计时记录只是本机观测，并非隔离硬件、重复统计的性能基准。loop128 比原版使用更多路径工作，未声称零开销。地图、响应32MiB、服务单请求超时和并发429机制未修改。

## 6. 质量指标定义

`corridor.quality` 来自实际 steps，而非 guideControls：

- maxStraightRun / straightRunSteps：完全相同离散(dx,dz)的连续步数和整条路线的分段列表；另存 maxStraightLength 的实际水平长度。12方向的(2,1)一步长度是√5，不能直接将步数当方块距离。
- effectiveBends：转向两侧各至少3步的弯折。它只表示最小持续性，必须结合短周期统计使用，不能单独证明“自然”。bendSpacings 包含两端到首/末弯的区间，单位为实际水平长度。
- sinuosity：水平中心线长度/端点水平直线距离。闭合零端点距离约定为0并同时保留 endpointDistance，避免无穷值。
- longStraightFraction：超过16步的整段长度占比，不是只计超过16的多余步数。
- microZigzagWindows / microZigzagRatio：原严格逐步ABAB窗口；rhythmZigzagWindows 额外统计 A^k B^k A^k B^k（k=2,3）。重叠窗口分别计数。
- routingAttempts：有序候选阶段、拒绝代码、搜索/grade工作、选中标记、补形结果。unguidedFallbackCount 只数最终选中的无 guide 路线；conservativeRouteCount 单列，失败尝试不冒充已提交道路。

旧 longestStraightRatio 与 microZigzagRatio 的网络汇总保留旧的“路线至少30个节点”口径；新逐路线审计与脚本会检查所有路线，避免短连接被汇总口径漏掉。routeQualityVersion=1 只在生成质量统计时标记。结构版本仍为 PlanningIR 0.4.0，质量字段是附加诊断，不授权任何施工编辑；PlanConstruction 与 groundColumns 的真源关系保持不变。

## 7. 实际测试结果与环境

最终全部退出码为0：core-21（21项）、adaptive-29（29项）、fuzz-100（100个确定性随机实例）、organic-presets-25（25项）、新增 route-richness（26项），以及 bridge-diagonal、bridge-loopback、fabric-syntax-only。新增26项包括8/12方向端点整数平衡、宽度1/3/5的真实补形、水体/保护区/悬崖/既有建筑保留、切填边界、状态/路径预算停止、ABAB与多步摆动区别、真实铺装重排、复现512集成、回退顺序与重放。

五场景×两次导出及独立指标复算通过；原脚本扩展后的API验证包含12个正常/预算场景请求、14个非法参数400、并发429、确定性重复、混合预设与单一中庭、参考与复现环路检查。低施工预算请求返回INFEASIBLE、0栋、0编辑，而不是偷偷提高预算。

浏览器实际运行原应用JS，保存五场景的原始/规划/施工视图及额外目录/对比图，共18张PNG，pageErrors=[]，五个 planHash 与独立导出一致。但托管Chromium直连loopback被管理员策略阻止，使用现有测试脚本的 Python→真实本机HTTP 桥接；不是模拟API。WebGL不可用，实测为原页面的2D兼容模式。没有声称原生Chromium loopback或3D光栅显示通过。

浏览器 custom192x96 在验证中庭卡片后保留 singlePresetId=courtyard_house；由于 presetPalette=classic，此字段不参与选型，其最终planHash与独立导出 square_cabin 参数的同场景一致。核心/API非方形参数与指定场景一致，不据此假称两个HTTP参数对象逐字相同。

环境：Java 21.0.11，Python 3.13.5，真实Gson 2.8.9（由本地已有jar提供）。项目声明的Gson2.10.1未在此环境验证；两端采用同版本作公平对比，没有改依赖声明、没有伪造Gson替身。交接提到的Windows classpath失败不能作为本次结果：本次Linux环境主源码、可执行测试及本地HTTP桥接均实际运行通过。未执行Fabric完整依赖类型构建、Minecraft游戏运行或真实3D显示；fabric-syntax-only只代表Java语法解析。

证据入口：
- before / after：完整 PlanningIR.json、summary.json、route-metrics.json、地形压缩数据和执行日志；after另含repeat。
- comparison.json：参数/地形/建筑锁定断言、质量警报、逐次回退原因。
- final-tests/verification-status.json、final-tests/route-richness/results.json、final-tests/environment.json。
- api/api-checks.json、api/reproduction512-response.json.gz。
- browser/browser-results.json、visual/index.html、五张 comparison.png。
- acceptance-commands.json 和 console/ 中实际命令输出。

## 8. 复跑命令

在完整包的 source 目录执行。需要本地Java21与真实Gson；默认找用户Gradle缓存中的2.10.1。无缓存时明确设置 GSON_JAR，脚本不联网下载依赖：

```powershell
# 仅在默认缓存找不到时设置真实文件路径：
$env:GSON_JAR = 'C:\deps\gson-2.10.1.jar'
python tools/build_offline.py --test --loopback-tests
python tools/verify_route_richness.py --out build/route-richness --repeat
python tools/preview_server.py --port 18767
# 另一个终端：
python tools/verify_preview_api.py --base http://127.0.0.1:18767 --out build/api-verification-v041
```

浏览器证据脚本需已安装Playwright和本地Chromium；Linux示例：

```sh
python tools/verify_organic_browser.py --base http://127.0.0.1:18767 --out build/browser-v041 --chromium /usr/bin/chromium
python tools/render_route_comparisons.py --before ../evidence/v041/before --after ../evidence/v041/after --out build/route-comparison
python tools/compare_route_richness.py --before ../evidence/v041/before --after ../evidence/v041/after --out build/comparison.json
```

PNG对比工具仅额外需要Pillow/numpy，核心规划不依赖它们。构建产物和本机Gson jar不随包分发。
