# 路线丰富度 v0.4.1 变更说明

## 本轮范围

实现 Organic Road Network 的真实路线丰富度改进；不重新生成地形，不改变22个建筑预设、建筑选址/平台规则或浏览器布局。PlanningIR结构版本保持0.4.0，新增诊断字段兼容原施工消费链。该包是已实现版本，不是只转交需求的handoff。

## 实际调用链

preview.html → preview_server.py → SimulationApiRunner → SimulatedSettlementPipeline → BoundedSettlementPlanner → OrganicRoadNetwork → TerrainRoadRouter → PavementGrades → PlanningIR.groundColumns → PlanConstruction。

原始可行性布置/私有入口仍先产生并锁定，语义网络重建失败仍原子退回已验证布局。新质量统计不参与生成第二份道路或越过groundColumns执行施工。

## 修改机制

### OrganicGuide

将单一二次弧提案扩为四个有限、确定的角色化提案：collector/local 使用镜像S形与分段弧，secondary/ring 使用不同外偏幅度的镜像弧；稀疏控制点以Catmull–Rom采样。local幅度更保守。种子只决定有限提案的取向，不给每个点叠加随机噪声。

提案先按全宽障碍采样、切填高度区间、地形起伏与长度排序；实际尝试时再生成距离/剩余进度场，引导真实高度状态A*。预评分只是软成本，不代替全宽可施工性判断。第五个提案保留保守二次弧。

### TerrainRoadRouter

有guide时的连续同向状态由最多4步扩大为24步，超过角色偏好后逐步增加成本。长直路是软惩罚，不强迫必要直达道路碰撞或折返。原有8/12方向、全宽supercover、标高状态及楼梯可通行验证保留。

选定语义路线后，最多尝试有限的低频稀疏偏移：8/12方向通过整数向量配平保留两端坐标，重新求高度并通过完整PavementGrades。还会将两步/三步为块的 A^k B^k A^k B^k 整理成更长的方向段；实际中心线与足迹随之重建，并经过全宽和全路坡度验证。两类处理共享最多2048原路径工作额；失败原样保留。它们只作用于语义候选选定之后，不改变初始建筑可行性选择。

### OrganicRoadNetwork

固定尝试顺序：四个丰富候选 → 保守guide → 无guide。前四个仍尽量分离既有道路；后两个允许安全复用铺装，但环路仍必须增加新铺装与宏观围合。施工可行候选再综合比较长度、切填、楼梯、方向节奏、绕行与长直段质量。找到可行丰富候选后，不为缩短路线再降级到无guide。

每次候选都记录阶段、具体失败代码与预算消耗；`conservative_guided` 和 `constrained_fallback` 明确区分，带 fallbackReason。整网重建失败仍保留全体原建筑并标记FEASIBILITY_FALLBACK，已经选中的临时路线标记ROLLED_BACK。

经核对，旧认证corridor在原代码中影响的是hub候选，不会直接作为新collector的固定路径。本轮保留hub规则和建筑布局，以避免把选址变化包装成路线算法改善。新路由没有重新读入旧走廊作为必须沿用的中心线。

### RouteQualityMetrics / PlanningIR

新增实际steps的连续段列表、最大同向段、有效弯折与间距、绕行率、长直段占比、ABAB微锯齿、多步短周期摆动统计，以及回退计数和尝试日志。补充guide预评分/场扫描与中心线修整工作计数。16步以上路线保留解释性警报，警报不意味着建筑不可施工。

### 测试与工具

新增26项 RouteRichnessMain 测试，以及同一Java导出器、五场景确定性重放、独立指标复算/公平比较、实际IR可视化。现有API脚本增加精确复现请求及classic地形参数的明确拒绝；浏览器脚本增加复现与非方形场景。未修改preview.html或vendor渲染代码。

## 结果摘要

复现512主干最大同向段24→13；全部路线最大14。参考512两条主要collector分别18→7、38→15，长直段总长度占比49.45%→9.58%。五场景均7/7、全宽/坡度审计零违规并保有一个verified loop；mixed128由无loop增加到一个loop。

仍保留参考512的32/23步段及3个多步摆动窗口、mixed128的24/17步段，以及复现512两次追加ring尝试失败。完整触发坐标、失败原因、预算与环境说明见VALIDATION_V041_ZH.md；未声称所有路线都消除了直段。

## 交付

完整源码在source/，增量补丁为changes.diff（以source/为应用根目录）。evidence/v041包含前后数据、双次重放、26项新测试、原套件、API、浏览器和五场景对比。SHA256清单用于校验，不包含编译类、本地jar或字体文件。
