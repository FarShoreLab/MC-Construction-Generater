# Organic Road Network v0.4.1 · 路线丰富度实现版

这是完整可构建源码包，不是原“尚未修改算法”的handoff。只使用本包即可；changes.diff仅供已有原source快照的增量更新。

## 快速查看

先看 `evidence/v041/visual/index.html`：五个场景按相同地形、裁剪与比例绘制前后真实铺装/中心线。重点是 `reproduction512-comparison.png` 和 `reference512-comparison.png`。浏览器实际页面截图在 `evidence/v041/browser/`。

`CHANGELOG_V041_ZH.md` 说明机制；`VALIDATION_V041_ZH.md` 给出参数、指标、残留问题和测试环境。复现主干24→13步，参考场景长直段长度占比49.45%→9.58%；五场景均7/7并保持环路，但仍有明确保留的长直段警报，并非“所有路线小于16步”。

## 启动

进入 `source/`，准备Java21、Python和真实Gson。构建脚本优先使用本机Gradle中的Gson2.10.1；找不到时设置 `GSON_JAR` 指向实际jar。

```powershell
cd source
python tools/build_offline.py
python tools/preview_server.py --port 18767
```

打开 `http://127.0.0.1:18767/`，设置：512×512 / rolling_hills / relief24 / terrainSeed42 / planSeed45 / 7栋 / 12方向 / 对角建筑关闭 / mixed，再点击生成并查看“规划叠加”“施工结果”。默认页面参数不等于该精确复现请求。

全测试：

```powershell
python tools/build_offline.py --test --loopback-tests
python tools/verify_route_richness.py --out build/route-richness --repeat
# 预览服务在另一个终端运行时：
python tools/verify_preview_api.py --base http://127.0.0.1:18767 --out build/api-verification-v041
```

## 目录与已知范围

- `source/`：完整源码、原有工具及新增测试；未打包编译产物或本地依赖。
- `changes.diff`：相对于输入包source的unified diff；`SOURCE_SHA256SUMS.txt`校验所有源码文件。
- `evidence/v041/before/` 与 `after/`：五场景真实IR、指标、地形、日志；after包含repeat。
- `evidence/v041/final-tests/`、`api/`、`browser/`、`visual/`：可追溯测试与图像。
- `references/` 与 `PROMPT_ROUTE_RICHNESS_ZH.md`：输入交接材料，属于历史记录，不替代本轮报告。

本机完整核心与桥接验证通过；Gson实际为2.8.9而非声明的2.10.1。浏览器实测通过现有Python桥接访问真实本机API，显示2D兼容模式；未验证本机原生WebGL、Fabric完整依赖类型构建或Minecraft运行。详见报告，不能将syntax-only当作游戏环境验收。
