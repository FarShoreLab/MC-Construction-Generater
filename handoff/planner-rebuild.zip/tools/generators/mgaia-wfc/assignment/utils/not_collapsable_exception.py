class NotCollapsableException(Exception):
    pass
